<footer class="main-footer">
    <div class="footer-right">
      Copyright &copy; 2022 @ Stiafdial Malik
      
      
    </div>
    <div class="footer-right">

    </div>
  </footer>