<?php
	#urutane "localhost", "username mu", "password mu", "nama satabase mu"
	
	$conn = mysqli_connect("localhost", "root", "", "rekam_medis");
?>