# RekamMedis

Native Website with PHP, JS, Bootstrap....
Sistem rekam medis untuk rumah sehat dsb.

saat login
gunakan username : stiafdialmalik
paswword : 1234

semoga bisa terbantu